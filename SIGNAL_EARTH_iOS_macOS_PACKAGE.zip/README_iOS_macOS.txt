SIGNAL://EARTH — iOS / macOS
MN24 STUDIOS IA · Mythic Gate · From Earth

================================================
CÓMO JUGAR EN iOS (iPhone / iPad)
================================================
1. Copia la carpeta SIGNAL_EARTH_iOS_macOS a tu Mac o súbela a un hosting
   (GitHub Pages, Netlify, o un servidor simple).
2. Abre index.html en Safari (o la URL si está online).
3. En Safari: botón Compartir → "Añadir a pantalla de inicio".
4. Ábrelo como app a pantalla completa (landscape recomendado).
5. Controles: toca ↑ ↓ ⚔ o usa teclado externo si tienes.

================================================
CÓMO JUGAR EN macOS
================================================
1. Abre index.html con Safari o Chrome (doble clic o Arrastrar a Safari).
2. Teclado: W/↑ saltar · S/↓ cubrir · J/X o clic en ⚔ atacar.
3. Pantalla completa: Cmd+Ctrl+F (Safari) o el botón del navegador.

================================================
LÍMITES IMPORTANTES (honestidad técnica)
================================================
- Esto NO es una app nativa de App Store ni Mac App Store.
- Para publicar en App Store se necesita: Mac + Xcode + cuenta Apple Developer
  (99 USD/año) + empaquetado con WKWebView o motor Godot/Unity export iOS.
- Este paquete SÍ es el mismo juego completo jugable en Safari iOS y macOS,
  listo para portfolio, demos y "Añadir a pantalla de inicio".

================================================
SIGUIENTE PASO HACIA APP STORE
================================================
1. Llevar el mismo diseño a Godot 4 o Unity.
2. Export iOS / macOS con certificados de Apple.
3. TestFlight → App Store Connect.

Studio: MN24 STUDIOS IA
