#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/assets/console"
echo "MN24 Sky Bolt v1.0"
echo "Abre: http://127.0.0.1:8080"
python -m http.server 8080 --bind 127.0.0.1
