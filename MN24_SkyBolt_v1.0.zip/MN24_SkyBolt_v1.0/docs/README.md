# MN24 Sky Bolt v1.0

**Nuevo producto de videojuego** — Shoot-em-up vertical con nave eléctrica.

Parte del ecosistema **MN24 STUDIOS IA / MN24 Mobile Gaming Console**.

## Características

- Shoot-em-up vertical clásico
- 3 tipos de enemigos (scout, gunner, heavy)
- Sistema de power-ups (disparo múltiple)
- Bombas de pantalla completa
- Oleadas crecientes
- Controles táctiles + Gamepad API
- Listo para empaquetar como APK

## Controles

| Acción     | Táctil   | Teclado          | Mando            |
|------------|----------|------------------|------------------|
| Mover      | D-Pad    | WASD / Flechas   | Stick / D-Pad    |
| Disparar   | Botón A  | Espacio / J      | A (mantener)     |
| Bomba      | Botón B  | K / X            | B                |

## Cómo probar

```bash
cd MN24_SkyBolt_v1.0/assets/console
python -m http.server 8080 --bind 127.0.0.1
```

Abre: `http://127.0.0.1:8080`

## Estado

| Elemento                  | Estado       |
|---------------------------|--------------|
| Juego completo jugable    | IMPLEMENTADO |
| Shell + input + loader    | IMPLEMENTADO |
| Soporte mandos Bluetooth  | IMPLEMENTADO |
| APK compilado y firmado   | PENDIENTE    |

---

**MN24 STUDIOS IA** · From Earth · Remote · AI
