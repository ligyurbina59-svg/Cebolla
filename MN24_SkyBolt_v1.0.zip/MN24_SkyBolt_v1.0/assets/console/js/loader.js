/**
 * MN24 Game Loader — Sky Bolt
 */
const MN24Loader = {
  current: null,
  _bridge: null,

  load(path) {
    const host = document.getElementById('game-host');
    const frame = document.getElementById('game-frame');
    const shell = document.getElementById('shell');
    if (!host || !frame) return;

    this.current = 'skybolt';
    frame.src = path;
    shell.classList.add('hidden');
    host.classList.remove('hidden');

    const pad = document.getElementById('touch-pad');
    const showTouch = document.getElementById('opt-touch')?.checked !== false;
    if (pad) {
      pad.classList.toggle('hidden', !showTouch);
      MN24Input.bindTouch(pad);
    }

    clearInterval(this._bridge);
    this._bridge = setInterval(() => {
      try {
        const w = frame.contentWindow;
        if (!w) return;
        w.postMessage({ type: 'mn24-input', state: MN24Input.snapshot() }, '*');
      } catch (_) {}
    }, 16);

    try { document.documentElement.requestFullscreen?.(); } catch (_) {}
  },

  unload() {
    clearInterval(this._bridge);
    const host = document.getElementById('game-host');
    const frame = document.getElementById('game-frame');
    const shell = document.getElementById('shell');
    if (frame) frame.src = 'about:blank';
    if (host) host.classList.add('hidden');
    if (shell) shell.classList.remove('hidden');
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch (_) {}
    this.current = null;
  }
};
