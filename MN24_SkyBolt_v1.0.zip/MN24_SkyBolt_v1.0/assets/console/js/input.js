/**
 * MN24 Input Manager — Sky Bolt v1.0
 */
const MN24Input = {
  state: {
    up: false, down: false, left: false, right: false,
    a: false, b: false, ax: 0, ay: 0
  },
  vibrate: true,
  padName: '',
  padConnected: false,

  init() {
    window.addEventListener('keydown', e => this._key(e, true));
    window.addEventListener('keyup', e => this._key(e, false));

    window.addEventListener('gamepadconnected', e => {
      this.padConnected = true;
      this.padName = e.gamepad.id || 'Gamepad';
      this._setPadUI(true, this.padName);
      this._buzz(25);
    });

    window.addEventListener('gamepaddisconnected', () => {
      const still = (navigator.getGamepads?.() || []).some(p => p);
      this.padConnected = still;
      if (!still) {
        this.padName = '';
        this._setPadUI(false, '');
      }
    });

    const loop = () => { this._pollPads(); requestAnimationFrame(loop); };
    requestAnimationFrame(loop);
  },

  bindTouch(root) {
    if (!root) return;
    root.querySelectorAll('[data-key]').forEach(btn => {
      const k = btn.dataset.key;
      const on = e => {
        e.preventDefault();
        this._set(k, true);
        this._buzz(12);
        btn.classList.add('pressed');
      };
      const off = () => {
        this._set(k, false);
        btn.classList.remove('pressed');
      };
      ['touchstart', 'mousedown'].forEach(ev =>
        btn.addEventListener(ev, on, { passive: false })
      );
      ['touchend', 'touchcancel', 'mouseup', 'mouseleave'].forEach(ev =>
        btn.addEventListener(ev, off)
      );
    });
  },

  snapshot() { return { ...this.state }; },

  _set(key, val) {
    const map = { up:'up', down:'down', left:'left', right:'right', a:'a', b:'b', ok:'a' };
    if (map[key]) this.state[map[key]] = val;
  },

  _key(e, down) {
    const k = e.key.toLowerCase();
    if (['arrowup','w'].includes(k)) this.state.up = down;
    if (['arrowdown','s'].includes(k)) this.state.down = down;
    if (['arrowleft','a'].includes(k)) this.state.left = down;
    if (['arrowright','d'].includes(k)) this.state.right = down;
    if ([' ','j','z'].includes(k)) this.state.a = down;
    if (['k','x'].includes(k)) this.state.b = down;
    if (down && ['arrowup','arrowdown','arrowleft','arrowright',' ','w','a','s','d','j','k','z','x'].includes(k)) {
      e.preventDefault();
    }
  },

  _pollPads() {
    const pads = navigator.getGamepads?.() || [];
    for (const p of pads) {
      if (!p) continue;
      this.padConnected = true;
      this.state.a = !!(p.buttons[0]?.pressed);
      this.state.b = !!(p.buttons[1]?.pressed);
      this.state.left  = !!(p.buttons[14]?.pressed) || (p.axes[0] < -0.35);
      this.state.right = !!(p.buttons[15]?.pressed) || (p.axes[0] > 0.35);
      this.state.up    = !!(p.buttons[12]?.pressed) || (p.axes[1] < -0.35);
      this.state.down  = !!(p.buttons[13]?.pressed) || (p.axes[1] > 0.35);
      this.state.ax = p.axes[0] || 0;
      this.state.ay = p.axes[1] || 0;
    }
  },

  _setPadUI(connected, name) {
    const el = document.getElementById('pad-status');
    const nameEl = document.getElementById('pad-name');
    const status = document.getElementById('status');
    if (el) el.textContent = connected ? 'Conectado' : 'Buscando…';
    if (nameEl) nameEl.textContent = connected ? name : 'Empareja un mando en Ajustes → Bluetooth.';
    if (status) status.textContent = connected ? '● Mando detectado' : '● Listo';
  },

  _buzz(ms) {
    if (this.vibrate && navigator.vibrate) navigator.vibrate(ms);
  }
};
