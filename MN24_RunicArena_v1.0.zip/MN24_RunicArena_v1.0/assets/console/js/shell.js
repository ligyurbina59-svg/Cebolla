/**
 * MN24 Shell — Runic Arena v1.0
 */
const Shell = {
  init() {
    MN24Input.init();
    MN24Input.vibrate = document.getElementById('opt-vibrate')?.checked !== false;

    document.getElementById('opt-vibrate')?.addEventListener('change', e => {
      MN24Input.vibrate = e.target.checked;
    });

    document.getElementById('btn-play')?.addEventListener('click', () => this.launch());
    document.getElementById('btn-fullscreen')?.addEventListener('click', async () => {
      try {
        if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
        else await document.exitFullscreen();
      } catch (e) {
        alert('Pantalla completa no disponible en este navegador.');
      }
    });
  },

  launch() {
    MN24Loader.load('games/runicarena/index.html');
  },

  exit() {
    MN24Loader.unload();
  }
};

document.addEventListener('DOMContentLoaded', () => Shell.init());
window.Shell = Shell;
