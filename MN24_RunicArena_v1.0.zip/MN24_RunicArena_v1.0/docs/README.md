# MN24 Runic Arena v1.0

**Nuevo producto de videojuego** — Arena de combate con oleadas y poderes rúnicos.

Parte del ecosistema **MN24 STUDIOS IA / MN24 Mobile Gaming Console**.

## Características

- Combate de arena (vista top-down)
- Oleadas de enemigos que aumentan en dificultad
- Disparo direccional + runa especial (nova)
- Controles táctiles + Gamepad API
- Sistema de vidas, puntuación y cooldown de habilidad
- Listo para empaquetar como APK

## Controles

| Acción        | Táctil / Botones | Teclado           | Mando              |
|---------------|------------------|-------------------|--------------------|
| Mover         | D-Pad            | WASD / Flechas    | Stick izquierdo    |
| Disparar      | Botón A          | Espacio / J / Z   | A / Stick derecho  |
| Runa especial | Botón B          | K / X             | B                  |

## Cómo probar

```bash
cd MN24_RunicArena_v1.0/assets/console
python -m http.server 8080 --bind 127.0.0.1
```

Abre: `http://127.0.0.1:8080`

## Estado

| Elemento                    | Estado        |
|----------------------------|---------------|
| Juego completo jugable     | IMPLEMENTADO  |
| Shell + input + loader     | IMPLEMENTADO  |
| Soporte mandos Bluetooth   | IMPLEMENTADO  |
| APK compilado y firmado    | PENDIENTE     |

## Cómo generar APK

Mismo método que `MN24_Console_GAMEPAD_v1.2.apk` y `PHANTASM_MN24_v1.0.apk`:
sustituir el contenido de `assets/console/` o integrarlo como juego adicional en la consola.

---

**MN24 STUDIOS IA** · From Earth · Remote · AI
