# STORMRUNER: THUNDER OF THE NORTH — MVP v0.1

MVP jugable en Godot 4.

## Incluye
- Movimiento horizontal
- Salto
- Ataque cuerpo a cuerpo
- Poder THUNDER
- 3 enemigos
- Frost Warden (jefe) con 300 HP
- HP, Thunder y HUD
- Controles táctiles Android
- Checkpoint básico al morir
- Escenario "The Frozen Gate"
- Sin assets externos: todo se dibuja con Godot

## Ejecutar
1. Abrir el proyecto en Godot 4.x.
2. Ejecutar `Main.tscn`.
3. PC: A/D, Espacio, J/X, K/C.
4. Android: botones táctiles.

## Exportar Android
En Godot configura el Android SDK/JDK desde Editor > Editor Settings > Export > Android.
Después: Project > Export > Android > APK.

## Próxima versión
- sprites/arte
- animaciones
- inventario
- habilidades desbloqueables
- mapa Metroidvania
- sonido/música
- guardado persistente
- más jefes y zonas
