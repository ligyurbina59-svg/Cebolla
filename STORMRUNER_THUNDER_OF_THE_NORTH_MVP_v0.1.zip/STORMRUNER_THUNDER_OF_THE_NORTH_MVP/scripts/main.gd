extends Node2D

var player
var enemies: Array[Node] = []
var boss
var message := "THE FROZEN GATE"
var message_timer := 3.0

func _ready() -> void:
    queue_redraw()
    player = preload("res://scripts/player.gd").new()
    player.position = Vector2(220, 500)
    player.name = "Stormrunner"
    add_child(player)

    for p in [Vector2(560, 500), Vector2(760, 500), Vector2(950, 500)]:
        spawn_enemy(p)

    var hud = preload("res://scripts/hud.gd").new()
    add_child(hud)
    hud.set_player(player)

    boss = preload("res://scripts/boss.gd").new()
    boss.position = Vector2(1120, 470)
    boss.name = "FrostWarden"
    add_child(boss)
    boss.player = player

func spawn_enemy(p: Vector2) -> void:
    var e = preload("res://scripts/enemy.gd").new()
    e.position = p
    e.player = player
    add_child(e)
    enemies.append(e)

func _process(delta: float) -> void:
    message_timer = maxf(0.0, message_timer - delta)
    queue_redraw()
    if is_instance_valid(player):
        if player.position.x > 1180 and is_instance_valid(boss) and boss.dead:
            message = "THE THUNDER OF THE NORTH IS YOURS"
            message_timer = 999.0
        elif player.position.x > 1050 and is_instance_valid(boss) and not boss.dead:
            message = "FROST WARDEN — DEFEAT THE GUARDIAN"
            message_timer = 0.5

func _draw() -> void:
    draw_rect(Rect2(0, 0, 1280, 720), Color("#07101c"))
    # sky bands
    draw_rect(Rect2(0, 0, 1280, 360), Color("#0b1d31"))
    draw_rect(Rect2(0, 360, 1280, 360), Color("#10151c"))
    # distant mountains
    var mountain = PackedVector2Array([
        Vector2(0,380), Vector2(160,220), Vector2(290,360), Vector2(430,190),
        Vector2(600,350), Vector2(780,170), Vector2(960,350), Vector2(1100,210),
        Vector2(1280,360), Vector2(1280,520), Vector2(0,520)
    ])
    draw_colored_polygon(mountain, Color("#172b3c"))
    # ground
    draw_rect(Rect2(0, 520, 1280, 200), Color("#182027"))
    for x in range(0, 1280, 80):
        draw_line(Vector2(x, 520), Vector2(x + 35, 545), Color("#26333a"), 2)
    # frozen gate
    draw_line(Vector2(1180, 520), Vector2(1180, 280), Color("#7fa8c2"), 10)
    draw_line(Vector2(1240, 520), Vector2(1240, 280), Color("#7fa8c2"), 10)
    draw_line(Vector2(1180, 290), Vector2(1240, 290), Color("#a8d5e8"), 10)
    if message_timer > 0:
        draw_string(ThemeDB.fallback_font, Vector2(360, 100), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color("#dcefff"))


func _enter_tree() -> void:
    pass
