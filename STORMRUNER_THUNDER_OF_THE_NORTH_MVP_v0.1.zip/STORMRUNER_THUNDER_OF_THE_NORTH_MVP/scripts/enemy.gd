extends CharacterBody2D

var player
var hp := 60
var speed := 75.0
var attack_cd := 0.0
var stunned := 0.0
var flash := 0.0

func _ready() -> void:
    add_to_group("enemies")
    z_index = 8
    queue_redraw()

func _physics_process(delta: float) -> void:
    attack_cd = maxf(0.0, attack_cd - delta)
    stunned = maxf(0.0, stunned - delta)
    flash = maxf(0.0, flash - delta)
    if is_instance_valid(player) and stunned <= 0:
        var d = player.global_position - global_position
        if abs(d.x) > 55:
            velocity.x = sign(d.x) * speed
        else:
            velocity.x = 0
            if attack_cd <= 0:
                player.take_damage(10)
                attack_cd = 1.0
    else:
        velocity.x = move_toward(velocity.x, 0, 500 * delta)
    move_and_slide()
    queue_redraw()

func take_damage(amount: int) -> void:
    hp -= amount
    flash = 0.15
    if hp <= 0:
        queue_free()

func _draw() -> void:
    draw_circle(Vector2(0,-25), 13, Color("#6f7780") if flash <= 0 else Color.WHITE)
    draw_rect(Rect2(-18,-12,36,38), Color("#37404a"))
    draw_line(Vector2(-12,20), Vector2(-20,45), Color("#222a30"), 7)
    draw_line(Vector2(12,20), Vector2(20,45), Color("#222a30"), 7)
