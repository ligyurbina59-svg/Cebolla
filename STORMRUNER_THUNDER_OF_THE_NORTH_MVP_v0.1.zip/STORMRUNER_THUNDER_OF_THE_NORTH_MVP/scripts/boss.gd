extends CharacterBody2D

var player
var hp := 300
var max_hp := 300
var speed := 48.0
var attack_cd := 0.0
var stunned := 0.0
var dead := false
var flash := 0.0

func _ready() -> void:
    add_to_group("enemies")
    z_index = 9
    queue_redraw()

func _physics_process(delta: float) -> void:
    if dead: return
    attack_cd = maxf(0.0, attack_cd - delta)
    stunned = maxf(0.0, stunned - delta)
    flash = maxf(0.0, flash - delta)
    if is_instance_valid(player) and stunned <= 0:
        var d = player.global_position - global_position
        if abs(d.x) > 100:
            velocity.x = sign(d.x) * speed
        else:
            velocity.x = 0
            if attack_cd <= 0:
                player.take_damage(20)
                attack_cd = 1.4
    move_and_slide()
    queue_redraw()

func take_damage(amount: int) -> void:
    hp -= amount
    flash = 0.12
    if hp <= 0:
        hp = 0
        dead = true
        queue_redraw()
        set_physics_process(false)

func _draw() -> void:
    var c = Color("#d9f2ff") if flash <= 0 else Color.WHITE
    draw_circle(Vector2(0,-55), 25, c)
    draw_rect(Rect2(-34,-32,68,75), Color("#456275"))
    draw_line(Vector2(-28,35), Vector2(-45,80), Color("#25343d"), 12)
    draw_line(Vector2(28,35), Vector2(45,80), Color("#25343d"), 12)
    draw_line(Vector2(-28,-12), Vector2(-60,12), c, 9)
    draw_line(Vector2(28,-12), Vector2(60,12), c, 9)
    draw_rect(Rect2(-70,-105,140,10), Color("#20252b"))
    draw_rect(Rect2(-70,-105,140.0 * float(hp) / max_hp,10), Color("#b7d8e8"))
    if dead:
        draw_string(ThemeDB.fallback_font, Vector2(-70,-125), "DEFEATED", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#dcefff"))
