extends Node2D

var life := 0.28

func _process(delta):
    life -= delta
    queue_redraw()
    if life <= 0:
        queue_free()

func _draw():
    var pts = PackedVector2Array([
        Vector2(0,-420), Vector2(-18,-250), Vector2(15,-170),
        Vector2(-10,-70), Vector2(8,20)
    ])
    draw_polyline(pts, Color("#dff7ff"), 10)
    draw_polyline(pts, Color("#8ad8ff"), 4)
