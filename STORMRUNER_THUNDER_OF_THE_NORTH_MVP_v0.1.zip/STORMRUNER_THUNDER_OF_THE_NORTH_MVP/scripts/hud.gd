extends CanvasLayer

var player
var info: Label

func _ready():
    info = Label.new()
    info.position = Vector2(24, 18)
    info.add_theme_font_size_override("font_size", 22)
    add_child(info)

    var help = Label.new()
    help.position = Vector2(24, 650)
    help.text = "A/D o ◀▶  •  ESPACIO: salto  •  J/X: ataque  •  K/C: TRUENO"
    help.add_theme_font_size_override("font_size", 16)
    add_child(help)

    make_button("◀", Vector2(30,560), "left")
    make_button("▶", Vector2(100,560), "right")
    make_button("⚔", Vector2(1040,560), "attack")
    make_button("⚡", Vector2(1140,560), "thunder")

func set_player(p):
    player = p

func _process(_delta):
    if is_instance_valid(player):
        info.text = "STORMRUNER  |  HP %d/100  |  THUNDER %d%%" % [player.hp, int(player.thunder)]

func make_button(txt: String, pos: Vector2, action: String):
    var b = Button.new()
    b.text = txt
    b.position = pos
    b.size = Vector2(64,64)
    b.add_theme_font_size_override("font_size", 26)
    add_child(b)
    b.button_down.connect(func():
        if action == "left": player.virtual_left = true
        elif action == "right": player.virtual_right = true
        elif action == "attack": player.virtual_attack = true
        elif action == "thunder": player.virtual_thunder = true
    )
    b.button_up.connect(func():
        if action == "left": player.virtual_left = false
        elif action == "right": player.virtual_right = false
    )
