extends CharacterBody2D

var speed := 280.0
var gravity := 1200.0
var jump_force := -520.0
var hp := 100
var max_hp := 100
var thunder := 100.0
var attack_cd := 0.0
var invuln := 0.0
var facing := 1.0
var flash := 0.0
var virtual_left := false
var virtual_right := false
var virtual_attack := false
var virtual_thunder := false

func _ready() -> void:
    z_index = 10
    queue_redraw()

func _physics_process(delta: float) -> void:
    attack_cd = maxf(0.0, attack_cd - delta)
    invuln = maxf(0.0, invuln - delta)
    flash = maxf(0.0, flash - delta)

    var axis := Input.get_axis("move_left", "move_right")
    if virtual_left: axis = -1.0
    if virtual_right: axis = 1.0
    velocity.x = move_toward(velocity.x, axis * speed, 1600.0 * delta)
    if axis != 0:
        facing = sign(axis)

    if is_on_floor():
        if Input.is_action_just_pressed("jump"):
            velocity.y = jump_force
    else:
        velocity.y += gravity * delta

    if Input.is_action_just_pressed("attack") or virtual_attack:
        attack()
        virtual_attack = false
    if Input.is_action_just_pressed("thunder") or virtual_thunder:
        cast_thunder()
        virtual_thunder = false

    move_and_slide()
    position.x = clampf(position.x, 30.0, 1250.0)
    position.y = minf(position.y, 520.0)
    queue_redraw()

func attack() -> void:
    if attack_cd > 0: return
    attack_cd = 0.35
    flash = 0.12
    for node in get_tree().get_nodes_in_group("enemies"):
        if is_instance_valid(node) and global_position.distance_to(node.global_position) < 100.0:
            var dir = sign(node.global_position.x - global_position.x)
            if dir == 0 or dir == facing:
                node.take_damage(25)

func cast_thunder() -> void:
    if thunder < 30: return
    thunder -= 30
    flash = 0.25
    for node in get_tree().get_nodes_in_group("enemies"):
        if is_instance_valid(node) and abs(node.global_position.x - global_position.x) < 330.0:
            node.take_damage(45)
            node.stunned = 0.6
    # visual lightning
    var fx = preload("res://scripts/thunder_fx.gd").new()
    fx.position = global_position
    get_parent().add_child(fx)

func take_damage(amount: int) -> void:
    if invuln > 0: return
    hp -= amount
    invuln = 0.7
    if hp <= 0:
        hp = max_hp
        position = Vector2(220, 500)

func _draw() -> void:
    var body = Color("#d9e7ef") if flash <= 0 else Color("#ffffff")
    draw_circle(Vector2(0, -28), 15, body)
    draw_rect(Rect2(-14, -14, 28, 45), Color("#3b6079"))
    draw_line(Vector2(-12, 0), Vector2(-32 * facing, 18), Color("#9ab8c8"), 7)
    draw_line(Vector2(12, 0), Vector2(35 * facing, 5), Color("#9ab8c8"), 7)
    draw_line(Vector2(8 * facing, -2), Vector2(48 * facing, -20), Color("#dbe9ef"), 5)

func _notification(what):
    if what == NOTIFICATION_DRAW:
        pass
